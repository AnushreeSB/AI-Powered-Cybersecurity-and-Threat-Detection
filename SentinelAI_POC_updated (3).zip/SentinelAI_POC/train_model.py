from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from features import FEATURES, NORMAL, ALL_LABELS, ATTACK_TYPES
import features as F

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
MODEL_PATH = MODEL_DIR / "sentinelai_attack_classifier_v2.joblib"

# Synthetic signature per label:
# (failed_logins range, connections/min range, bytes range, P(unusual_port), duration range)
SPEC = {
    F.NORMAL:           ("poisson", (1, 35),     (500, 800_000),            .04, (1, 600)),
    F.BRUTE_FORCE:      ((6, 60),   (10, 90),    (500, 300_000),            .20, (1, 300)),
    F.CRED_STUFFING:    ((20, 150), (1, 9),      (500, 100_000),            .10, (600, 3600)),
    F.PORT_SCAN:        ((0, 7),    (70, 250),   (500, 50_000),             1.0, (1, 60)),
    F.DOS_FLOOD:        ((0, 2),    (400, 3000), (100_000, 3_000_000),      .05, (1, 120)),
    F.EXFILTRATION:     ((0, 4),    (5, 70),     (5_000_000, 50_000_000),   .60, (10, 900)),
    F.C2_BEACONING:     ((0, 1),    (1, 5),      (500, 30_000),             .90, (3600, 86_400)),
    F.DNS_TUNNELING:    ((0, 1),    (120, 400),  (300_000, 3_000_000),      .03, (600, 7200)),
    F.WEB_ATTACK:       ((0, 4),    (36, 120),   (5_000, 300_000),          .05, (1, 20)),
    F.LATERAL_MOVEMENT: ((3, 15),   (10, 100),   (800_000, 4_500_000),      .70, (60, 1800)),
    F.RANSOMWARE:       ((0, 3),    (100, 300),  (5_000_000, 100_000_000),  .50, (30, 600)),
}


def make_row(rng, label):
    """One synthetic record for the given label (Normal or an attack type)."""
    fails, conns, nbytes, p_port, dur = SPEC[label]
    f = int(rng.poisson(1)) if fails == "poisson" else int(rng.integers(fails[0], fails[1] + 1))
    return [f, int(rng.integers(conns[0], conns[1] + 1)), int(rng.integers(nbytes[0], nbytes[1] + 1)),
            int(rng.random() < p_port), int(rng.integers(dur[0], dur[1] + 1))]


def make_demo_data(n=11000, seed=42):
    """Synthetic labelled data: 50% Normal, the rest split evenly across the 10 attack types."""
    rng = np.random.default_rng(seed)
    p = [0.50] + [0.50 / len(ATTACK_TYPES)] * len(ATTACK_TYPES)
    labels = rng.choice(ALL_LABELS, size=n, p=p)
    rows = [make_row(rng, lab) + [lab] for lab in labels]
    return pd.DataFrame(rows, columns=FEATURES + ["label"])


def main():
    MODEL_DIR.mkdir(exist_ok=True)
    (ROOT / "data").mkdir(exist_ok=True)
    df = make_demo_data()
    X_train, X_test, y_train, y_test = train_test_split(df[FEATURES], df["label"], test_size=.25, random_state=42, stratify=df["label"])
    model = RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    print("SYNTHETIC DEMO DATA ONLY - not CIC-IDS2017 results")
    print("Accuracy:", round(accuracy_score(y_test, pred), 4))
    print(classification_report(y_test, pred))
    print("Confusion matrix (rows=true, cols=predicted):", list(model.classes_))
    print(confusion_matrix(y_test, pred, labels=model.classes_))
    joblib.dump(model, MODEL_PATH)
    make_demo_data(250, 7).to_csv(ROOT / "data" / "demo_training_sample.csv", index=False)
    print("Saved model to", MODEL_PATH.relative_to(ROOT))


if __name__ == "__main__":
    main()
