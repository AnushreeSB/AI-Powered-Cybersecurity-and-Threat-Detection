FEATURES = ["failed_login_attempts", "connections_per_minute", "bytes_sent", "unusual_port", "duration_seconds"]

NORMAL = "Normal"
BRUTE_FORCE = "Brute Force"
CRED_STUFFING = "Credential Stuffing"
PORT_SCAN = "Port Scan"
DOS_FLOOD = "DoS / DDoS Flood"
EXFILTRATION = "Data Exfiltration"
C2_BEACONING = "Malware C2 Beaconing"
DNS_TUNNELING = "DNS Tunneling"
WEB_ATTACK = "Web Application Attack"
LATERAL_MOVEMENT = "Lateral Movement"
RANSOMWARE = "Ransomware Activity"

# name, what it is, typical signs in the five features, MITRE ATT&CK reference, minimum severity
ATTACK_CATALOG = [
    {"name": BRUTE_FORCE, "mitre": "T1110", "base": "Medium",
     "info": "Attacker rapidly guesses passwords against an account or service.",
     "signs": "Many failed logins at a moderate connection rate."},
    {"name": CRED_STUFFING, "mitre": "T1110.004", "base": "Medium",
     "info": "Stolen username/password lists tried slowly to avoid lockouts.",
     "signs": "Very many failed logins, very few connections, long duration."},
    {"name": PORT_SCAN, "mitre": "T1046", "base": "Medium",
     "info": "Reconnaissance: probing many ports or hosts to find open services.",
     "signs": "Very high connection rate, tiny short sessions, unusual port."},
    {"name": DOS_FLOOD, "mitre": "T1498", "base": "High",
     "info": "Traffic flood meant to knock a service offline.",
     "signs": "Extreme connections per minute on normal ports, short sessions."},
    {"name": EXFILTRATION, "mitre": "T1041", "base": "Critical",
     "info": "Large-scale theft of data sent out of the network.",
     "signs": "Huge outbound data volume at a modest connection rate."},
    {"name": C2_BEACONING, "mitre": "T1071", "base": "High",
     "info": "Infected host quietly checking in with an attacker's command server.",
     "signs": "Almost no connections, tiny transfers, unusual port, very long sessions."},
    {"name": DNS_TUNNELING, "mitre": "T1071.004", "base": "High",
     "info": "Data or commands hidden inside DNS traffic to bypass controls.",
     "signs": "High connection rate on a normal port, medium data, long sessions."},
    {"name": WEB_ATTACK, "mitre": "T1190", "base": "High",
     "info": "SQL injection / XSS style probing of a public web application.",
     "signs": "Elevated connection rate, very short sessions, normal port."},
    {"name": LATERAL_MOVEMENT, "mitre": "T1021", "base": "High",
     "info": "Attacker spreading between internal machines (SMB/RDP).",
     "signs": "Some failed logins, elevated data volume, unusual port, mid-length sessions."},
    {"name": RANSOMWARE, "mitre": "T1486", "base": "Critical",
     "info": "Malware spreading over the network and moving large amounts of data.",
     "signs": "High connection rate combined with very large data transfer."},
]

ATTACK_TYPES = [a["name"] for a in ATTACK_CATALOG]
ALL_LABELS = [NORMAL] + ATTACK_TYPES
ATTACK_INFO = {a["name"]: a["info"] for a in ATTACK_CATALOG}
_BASE = {a["name"]: a["base"] for a in ATTACK_CATALOG}
_LEVELS = ["Low", "Medium", "High", "Critical"]


def category_for(label):
    """Normal / Suspicious category from the model's detailed label."""
    return "Normal" if label == NORMAL else "Suspicious"


def attack_for(label):
    """Attack name for suspicious rows, 'None' for normal rows."""
    return "None" if label == NORMAL else label


def severity_for(row, label):
    """Highest of: the attack's base severity, and a score from how extreme the features are."""
    if label == NORMAL:
        return "Low"
    score = 0
    if row["failed_login_attempts"] >= 10: score += 2
    elif row["failed_login_attempts"] >= 5: score += 1
    if row["connections_per_minute"] >= 100: score += 2
    elif row["connections_per_minute"] >= 50: score += 1
    if row["bytes_sent"] >= 5_000_000: score += 2
    if int(row["unusual_port"]) == 1: score += 1
    by_score = "Critical" if score >= 5 else "High" if score >= 3 else "Medium"
    return _LEVELS[max(_LEVELS.index(by_score), _LEVELS.index(_BASE.get(label, "Medium")))]


def explain_row(row, label):
    if label == NORMAL:
        return "No strong suspicious pattern was found in the supplied demo features."
    reasons = []
    if row["failed_login_attempts"] >= 5: reasons.append(f'{int(row["failed_login_attempts"])} failed login attempts')
    if row["connections_per_minute"] >= 50: reasons.append(f'{int(row["connections_per_minute"])} connections per minute')
    elif row["connections_per_minute"] <= 5 and row["duration_seconds"] >= 3600: reasons.append("very few connections kept open for a long time")
    if row["bytes_sent"] >= 5_000_000: reasons.append(f'high outbound data volume ({int(row["bytes_sent"]):,} bytes)')
    elif row["bytes_sent"] >= 800_000: reasons.append(f'elevated data volume ({int(row["bytes_sent"]):,} bytes)')
    if int(row["unusual_port"]) == 1: reasons.append("an unusual port flag")
    if row["duration_seconds"] >= 3600: reasons.append(f'a long session ({int(row["duration_seconds"]):,} s)')
    elif row["duration_seconds"] <= 20: reasons.append(f'very short sessions ({int(row["duration_seconds"])} s)')
    if not reasons: reasons.append("a combination of features associated with this attack pattern")
    return f"Classified as {label}: " + ATTACK_INFO[label] + " Evidence: " + ", ".join(reasons) + "."
