// Filter the results table by category (Normal / Suspicious) or by attack type.
document.addEventListener("DOMContentLoaded", function () {
  var filters = document.getElementById("filters");
  var table = document.getElementById("results-table");
  if (!filters || !table) return;
  filters.addEventListener("click", function (e) {
    var btn = e.target.closest(".filter");
    if (!btn) return;
    filters.querySelectorAll(".filter").forEach(function (b) { b.classList.remove("active"); });
    btn.classList.add("active");
    var kind = btn.dataset.kind, value = btn.dataset.value;
    table.querySelectorAll("tbody tr").forEach(function (row) {
      var show = !value || (kind === "pred" ? row.dataset.pred === value : row.dataset.attack === value);
      row.style.display = show ? "" : "none";
    });
  });
});
