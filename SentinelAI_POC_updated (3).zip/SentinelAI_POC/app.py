from pathlib import Path
import io
import json
import sqlite3
from datetime import datetime
import joblib
import pandas as pd
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response, abort
from werkzeug.utils import secure_filename
from features import (FEATURES, ATTACK_TYPES, ATTACK_CATALOG, ALL_LABELS, severity_for, explain_row, category_for, attack_for)

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "sentinelai_attack_classifier_v2.joblib"
UPLOAD_DIR = ROOT / "uploads"
RESULTS_DIR = ROOT / "results"
UPLOAD_DIR.mkdir(exist_ok=True)
RESULTS_DIR.mkdir(exist_ok=True)
DB_PATH = ROOT / "sentinelai.db"

# Columns we add to every output file
OUT_COLS = ["row", "prediction", "attack_type", "severity", "confidence_pct", "explanation"]

app = Flask(__name__)
app.secret_key = "replace-this-demo-secret-before-deployment"
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024


@app.context_processor
def inject_version():
    return {"attack_count": len(ATTACK_TYPES)}


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS analyses (id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL, analyzed_at TEXT NOT NULL, total INTEGER NOT NULL, suspicious INTEGER NOT NULL)")
        # Upgrade older databases created by the first POC version
        cols = [r["name"] for r in con.execute("PRAGMA table_info(analyses)")]
        if "attack_summary" not in cols:
            con.execute("ALTER TABLE analyses ADD COLUMN attack_summary TEXT DEFAULT '{}'")


init_db()


def get_model():
    """Load the model; train it automatically on first run if it does not exist yet."""
    model = joblib.load(MODEL_PATH) if MODEL_PATH.exists() else None
    # Retrain if the model is missing or was trained for a different set of attack types
    if model is None or set(map(str, model.classes_)) != set(ALL_LABELS):
        import train_model
        train_model.main()
        model = joblib.load(MODEL_PATH)
    return model


def logged_in():
    return "user" in session


def sanitize(value):
    """Stop spreadsheet formula injection when the output CSV is opened in Excel."""
    if isinstance(value, str) and value[:1] in ("=", "+", "-", "@"):
        return "'" + value
    return value


def run_analysis(df, model):
    """Classify every row. Returns the input table with prediction columns added."""
    missing = [c for c in FEATURES if c not in df.columns]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))
    if df.empty:
        raise ValueError("The CSV has no data rows.")
    X = df[FEATURES].apply(pd.to_numeric, errors="coerce")
    if X.isna().any().any():
        raise ValueError("Required columns contain blank or non-numeric values.")
    labels = model.predict(X)
    confidence = model.predict_proba(X).max(axis=1)
    out = []
    for i, (_, row) in enumerate(X.iterrows()):
        rec, lab = row.to_dict(), str(labels[i])
        out.append({
            "row": i + 1,
            "prediction": category_for(lab),
            "attack_type": attack_for(lab),
            "severity": severity_for(rec, lab),
            "confidence_pct": round(float(confidence[i]) * 100, 1),
            "explanation": explain_row(rec, lab),
        })
    # If a previous results file is re-uploaded, drop its old output columns to avoid duplicates
    original = df.drop(columns=[c for c in OUT_COLS if c in df.columns]).copy()
    for col in original.select_dtypes(include="object").columns:
        original[col] = original[col].map(sanitize)
    return pd.concat([pd.DataFrame(out)[["row"]], original, pd.DataFrame(out).drop(columns=["row"])], axis=1)


def summarize(result_df):
    total = len(result_df)
    suspicious = int((result_df["prediction"] == "Suspicious").sum())
    attacks = {a: int((result_df["attack_type"] == a).sum()) for a in ATTACK_TYPES}
    return total, suspicious, attacks


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form.get("username") == "admin" and request.form.get("password") == "sentinel123":
            session["user"] = "admin"
            return redirect(url_for("dashboard"))
        flash("Incorrect demo username or password.")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
def dashboard():
    if not logged_in(): return redirect(url_for("login"))
    with db() as con:
        records = con.execute("SELECT * FROM analyses ORDER BY id DESC LIMIT 8").fetchall()
        totals = con.execute("SELECT COALESCE(SUM(total),0), COALESCE(SUM(suspicious),0) FROM analyses").fetchone()
        summaries = con.execute("SELECT attack_summary FROM analyses").fetchall()
    attack_totals = {a: 0 for a in ATTACK_TYPES}
    for s in summaries:
        try:
            for k, v in json.loads(s["attack_summary"] or "{}").items():
                if k in attack_totals: attack_totals[k] += int(v)
        except (ValueError, TypeError):
            pass
    total, suspicious = totals[0], totals[1]
    return render_template("dashboard.html", records=records, total=total, suspicious=suspicious,
                           normal=max(total - suspicious, 0), attack_totals=attack_totals)


@app.route("/analyze", methods=["GET", "POST"])
def analyze():
    if not logged_in(): return redirect(url_for("login"))
    if request.method == "POST":
        upload = request.files.get("file")
        if not upload or not upload.filename:
            flash("Choose a CSV file first."); return redirect(url_for("analyze"))
        if not upload.filename.lower().endswith(".csv"):
            flash("Only CSV files are accepted."); return redirect(url_for("analyze"))
        filename = secure_filename(upload.filename) or "upload.csv"
        path = UPLOAD_DIR / filename
        upload.save(path)
        try:
            model = get_model()
            result_df = run_analysis(pd.read_csv(path, keep_default_na=False), model)
            total, suspicious, attacks = summarize(result_df)
            with db() as con:
                cur = con.execute("INSERT INTO analyses(filename,analyzed_at,total,suspicious,attack_summary) VALUES(?,?,?,?,?)",
                                  (filename, datetime.now().strftime("%Y-%m-%d %H:%M"), total, suspicious, json.dumps(attacks)))
                analysis_id = cur.lastrowid
            result_df.to_csv(RESULTS_DIR / f"analysis_{analysis_id}.csv", index=False)
            return redirect(url_for("results", analysis_id=analysis_id))
        except Exception as exc:
            flash("Could not analyze file: " + str(exc)); return redirect(url_for("analyze"))
    return render_template("analyze.html", features=FEATURES, attacks=ATTACK_CATALOG)


def load_result(analysis_id):
    path = RESULTS_DIR / f"analysis_{analysis_id}.csv"
    if not path.exists():
        abort(404)
    with db() as con:
        meta = con.execute("SELECT * FROM analyses WHERE id=?", (analysis_id,)).fetchone()
    if meta is None:
        abort(404)
    # keep_default_na=False: the text "None" (used for normal rows) must not be read as a missing value
    return pd.read_csv(path, keep_default_na=False), meta


@app.route("/results/<int:analysis_id>")
def results(analysis_id):
    if not logged_in(): return redirect(url_for("login"))
    df, meta = load_result(analysis_id)
    total, suspicious, attacks = summarize(df)
    rows = df.to_dict("records")
    return render_template("results.html", results=rows, features=FEATURES, filename=meta["filename"],
                           analysis_id=analysis_id, total=total, suspicious=suspicious,
                           normal=total - suspicious, attacks=attacks)


@app.route("/download/<int:analysis_id>/<kind>")
def download(analysis_id, kind):
    """kind: all | normal | suspicious"""
    if not logged_in(): return redirect(url_for("login"))
    if kind not in ("all", "normal", "suspicious"):
        abort(404)
    df, meta = load_result(analysis_id)
    if kind == "normal":
        df = df[df["prediction"] == "Normal"]
    elif kind == "suspicious":
        df = df[df["prediction"] == "Suspicious"]
    stem = Path(meta["filename"]).stem
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{stem}_{kind}.csv"'})


@app.route("/health")
def health():
    return {"status": "ok", "model_ready": MODEL_PATH.exists(), "attack_types": len(ATTACK_TYPES), "version": "v2-10-attacks"}


if __name__ == "__main__":
    app.run(debug=True)
