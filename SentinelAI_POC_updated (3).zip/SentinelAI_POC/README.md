# SentinelAI – Basic Proof of Concept

## What this POC does
- Trains a Random Forest model on labelled synthetic demonstration records.
- Accepts CSV uploads with five required security-log features.
- Classifies each row as Normal or Suspicious.
- For suspicious rows, names which of the 10 attack types triggered the flag (listed below and on the Log Analysis page).
- Displays severity, model confidence and an explanation with the evidence (e.g. "53 failed login attempts").
- Results page can be filtered by Normal / Suspicious / each attack type.
- Download results as CSV: all rows, suspicious only, or normal only.
- Stores analysis summaries in SQLite; past analyses can be reopened from the dashboard.

IMPORTANT: This is a demonstration POC. Accuracy on the synthetic data is ~100% because the synthetic classes barely overlap - this says nothing about real-world performance. The included model is trained on synthetic data, NOT CIC-IDS2017. It is not a production intrusion-detection system and must not be used for real security decisions. Do not upload confidential logs.

## Run on Windows
1. Extract this ZIP and open the `SentinelAI_POC` folder.
2. In the folder address bar, type `cmd` and press Enter.
3. Run:
   ```bat
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python train_model.py
   python app.py
   ```
4. Open http://127.0.0.1:5000

(`python train_model.py` is optional - the app trains the model automatically on first start if it is missing.)

Demo login: `admin` / `sentinel123`

## Required CSV columns
`failed_login_attempts`, `connections_per_minute`, `bytes_sent`, `unusual_port` (0/1), `duration_seconds`

Extra columns are allowed and are kept in the output.

## The 10 attack types
Brute Force (T1110), Credential Stuffing (T1110.004), Port Scan (T1046), DoS / DDoS Flood (T1498), Data Exfiltration (T1041), Malware C2 Beaconing (T1071), DNS Tunneling (T1071.004), Web Application Attack (T1190), Lateral Movement (T1021), Ransomware Activity (T1486). IDs are MITRE ATT&CK references.
To add or change an attack, edit `ATTACK_CATALOG` in `features.py` and its signature in `SPEC` in `train_model.py`, then delete `models/` and restart.

## Sample files
- `data/sample_security_logs.csv` - 300 rows, the five columns only (100 normal, 20 of each of the 10 attacks). Upload this for the demo.
- `data/sample_security_logs_with_ground_truth.csv` - same rows plus `expected_category` and `expected_attack`, so you can check the model's answers.

## Output CSV columns
Your original columns plus: `row`, `prediction` (Normal/Suspicious), `attack_type` (one of the 10 attacks, or None), `severity`, `confidence_pct`, `explanation`.

## Structure
- `app.py`: Flask routes, upload, prediction and SQLite history
- `train_model.py`: generates synthetic training data (Normal + 10 attack types) and trains Random Forest
- `features.py`: feature definitions, severity and explanations
- `templates/`: web pages
- `static/`: CSS and JavaScript
- `data/`: sample upload CSVs
- `results/`: saved output CSV for every analysis (created automatically)
- `models/`: model created after training (`sentinelai_attack_classifier_v2.joblib`)
- `sentinelai.db`: created automatically

## Next step toward CIC-IDS2017
Download CIC-IDS2017, inspect its actual columns, choose attack labels, then implement a reproducible feature mapping and preprocessing pipeline. Do not claim CIC-IDS2017 performance until the model is actually trained and evaluated on that dataset.
